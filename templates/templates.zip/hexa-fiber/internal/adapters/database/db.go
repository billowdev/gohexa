package database

import "fmt"

func NewDatabase() {
	fmt.Println("Initializing database...")
}
