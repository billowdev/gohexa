package filters

type TodoFilter struct {
	ID string `json:"id"`
	Name string `json:"name"`
	Status string `json:"status"`
}
