package configs

const (
	API_SUCCESS_CODE = "success"
	API_ERROR_CODE   = "failed"
)
